from django.contrib import admin
from admins.models import add_librarian
# Register your models here.

admin.site.register(add_librarian)
